#import "ActivationKeyAlert.h"
#import "Activation.h"




@implementation ActivationKeyAlert

- (void) show:(UIViewController *)viewController {
  NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
  NSString *activationKey = [userDefaults objectForKey:@"activationKey"];

  if (!activationKey) {
    UIAlertController * alert = [UIAlertController
                                  alertControllerWithTitle:@"Yahyaios"
message:@"Enter The Key"

                                  preferredStyle:UIAlertControllerStyleAlert];

    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"ENTER" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
      UITextField *activationKeyField = alert.textFields.firstObject;
      
      // [userDefaults setObject:activationKeyField.text forKey:@"activationKey"];
      
      Activation* activation = [[Activation alloc] init];
      [activation checkActivation:activationKeyField.text viewController:viewController];
    }];
    
    UIAlertAction* cancel = [UIAlertAction actionWithTitle:@"CANCEL" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
      exit(0);
    }];

    [alert addAction:ok];
    [alert addAction:cancel];

    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
      textField.placeholder = @"KEY";
    }];

    [viewController presentViewController:alert animated:YES completion:nil];
  } else {
    Activation* activation = [[Activation alloc] init];
    [activation checkActivation:activationKey viewController:viewController];
  }
}




@end


