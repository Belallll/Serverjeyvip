@interface ActivationKeyAlert : UIViewController <UIAlertViewDelegate>

- (void)show:(UIViewController *)viewController;

@end