
#import "Activation.h"
#import <sys/utsname.h>





@implementation Activation

- (id)init {
  self = [super init];
  [self initRequest];
  return self;
}
- (void)initRequest {
  struct utsname systemInfo;
  uname(&systemInfo);
  NSString* deviceModel = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
  self.activationURL = [NSURL URLWithString:@"Link Your Website/Cheack.php"];
  self.activationRequest = [[NSMutableURLRequest alloc] initWithURL:self.activationURL];
  [self.activationRequest setHTTPMethod:@"POST"];



  [self.activationRequest addValue:deviceModel forHTTPHeaderField:@"DEVICE-TYPE"];
  [self.activationRequest addValue:[[[UIDevice currentDevice] identifierForVendor] UUIDString] forHTTPHeaderField:@"DEVICE-ID"];
  [self.activationRequest addValue:[[UIDevice currentDevice] systemVersion] forHTTPHeaderField:@"DEVICE-OS-VERSION"];
  [self.activationRequest addValue:[[UIDevice currentDevice] name] forHTTPHeaderField:@"DEVICE-NAME"];
  [self.activationRequest addValue:[[UIDevice currentDevice] model] forHTTPHeaderField:@"DEVICE-MODEL"];


}



- (void)checkActivation:(NSString*)key viewController:(UIViewController*)viewController {
  [self.activationRequest addValue:key forHTTPHeaderField:@"ACTIVATION-KEY"];
  NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    



  NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];


  [NSURLConnection sendAsynchronousRequest:self.activationRequest queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {



    if (error) {
      if (![userDefaults objectForKey:@"activationKey"]) {
                    @throw NSInternalInconsistencyException;
      }
    }
    else {

NSHTTPURLResponse* httpResponse = (NSHTTPURLResponse*)response;
int code = [httpResponse statusCode];






if (code == 405 ) {
dispatch_async(dispatch_get_main_queue(), ^{

CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
UIView *customView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, 60)];
customView.backgroundColor =[UIColor colorWithRed:32/255.f green:180/255.f blue:2/255.f alpha:1.0];
customView.layer.cornerRadius = 0.0;

UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 0, customView.frame.size.width-40, 30)];
titleLabel.text = @"SUCCESS";
titleLabel.textAlignment = NSTextAlignmentLeft;
titleLabel.font = [UIFont systemFontOfSize:20 weight:UIFontWeightBold];
titleLabel.textColor =[UIColor colorWithRed:255/255.f green:255/255.f blue:255/255.f alpha:1.0];
[customView addSubview:titleLabel];

UILabel *messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 7.5, customView.frame.size.width-40, 80)];
messageLabel.text = key ;
messageLabel.numberOfLines = 0;
messageLabel.textColor =[UIColor colorWithRed:255/255.f green:255/255.f blue:255/255.f alpha:1.0];
messageLabel.textAlignment = NSTextAlignmentLeft;

[customView addSubview:messageLabel];

customView.center = CGPointMake(viewController.view.center.x, customView.frame.size.height/2);
[viewController.view addSubview:customView];

dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 5 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
    [customView removeFromSuperview];
});


UIView *ccustomView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, 0)];
ccustomView.backgroundColor =[UIColor clearColor];
ccustomView.layer.cornerRadius = 0.0;

UILabel *ttitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 120, 50)];
ttitleLabel.text = @"Yahyaios";
ttitleLabel.textAlignment = NSTextAlignmentCenter;
ttitleLabel.font = [UIFont systemFontOfSize:16
weight:UIFontWeightBold];
ttitleLabel.textColor =[UIColor colorWithRed:255/255.f green:0/255.f blue:0/255.f alpha:1.0];
[ccustomView addSubview:ttitleLabel];


ccustomView.center = CGPointMake(viewController.view.center.x, ccustomView.frame.size.height/2);
[viewController.view addSubview:ccustomView];


});

}

if (code == 404) {
    
dispatch_async(dispatch_get_main_queue(), ^{

CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
UIView *customView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, 60)];
customView.backgroundColor =[UIColor colorWithRed:225/255.f green:155/255.f blue:15/255.f alpha:1.0];
customView.layer.cornerRadius = 0.0;

UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 0, customView.frame.size.width-40, 30)];
titleLabel.text = @"ERROR 404";
titleLabel.textAlignment = NSTextAlignmentLeft;
titleLabel.font = [UIFont systemFontOfSize:20 weight:UIFontWeightBold];
titleLabel.textColor =[UIColor colorWithRed:255/255.f green:255/255.f blue:255/255.f alpha:1.0];
[customView addSubview:titleLabel];

UILabel *messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 7.5, customView.frame.size.width-40, 80)];
messageLabel.text = @"The Key is Expired";
messageLabel.numberOfLines = 0;
messageLabel.textColor =[UIColor colorWithRed:225/255.f green:255/255.f blue:255/255.f alpha:1.0];
messageLabel.textAlignment = NSTextAlignmentLeft;

[customView addSubview:messageLabel];

customView.center = CGPointMake(viewController.view.center.x, customView.frame.size.height/2);
[viewController.view addSubview:customView];

dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 5 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
    [customView removeFromSuperview];

[userDefaults setObject:nil forKey:@"activationKey"];
            @throw NSInternalInconsistencyException;

});

});        
}

if (code == 402) {
    
dispatch_async(dispatch_get_main_queue(), ^{

CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
UIView *customView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, 60)];
customView.backgroundColor =[UIColor colorWithRed:225/255.f green:0/255.f blue:0/255.f alpha:1.0];
customView.layer.cornerRadius = 0.0;

UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 0, customView.frame.size.width-40, 30)];
titleLabel.text = @"ERROR 402";
titleLabel.textAlignment = NSTextAlignmentLeft;
titleLabel.font = [UIFont systemFontOfSize:20 weight:UIFontWeightBold];
titleLabel.textColor =[UIColor colorWithRed:255/255.f green:255/255.f blue:255/255.f alpha:1.0];
[customView addSubview:titleLabel];

UILabel *messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 7.5, customView.frame.size.width-40, 80)];
messageLabel.text = @"The Key is Used";
messageLabel.numberOfLines = 0;
messageLabel.textColor =[UIColor colorWithRed:225/255.f green:255/255.f blue:255/255.f alpha:1.0];
messageLabel.textAlignment = NSTextAlignmentLeft;

[customView addSubview:messageLabel];

customView.center = CGPointMake(viewController.view.center.x, customView.frame.size.height/2);
[viewController.view addSubview:customView];

dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 5 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{

[userDefaults setObject:nil forKey:@"activationKey"];

            @throw NSInternalInconsistencyException;
});

});
        
}

if (code == 403) {
dispatch_async(dispatch_get_main_queue(), ^{

[userDefaults setObject:nil forKey:@"activationKey"];
   

CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
UIView *customView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, 60)];
customView.backgroundColor =[UIColor colorWithRed:225/255.f green:155/255.f blue:15/255.f alpha:1.0];
customView.layer.cornerRadius = 0.0;

UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 0, customView.frame.size.width-40, 30)];
titleLabel.text = @"WRONG KEY GAME WILL CRASH";
titleLabel.textAlignment = NSTextAlignmentLeft;
titleLabel.font = [UIFont systemFontOfSize:20 weight:UIFontWeightBold];
titleLabel.textColor =[UIColor colorWithRed:255/255.f green:255/255.f blue:255/255.f alpha:1.0];
[customView addSubview:titleLabel];

UILabel *messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 7.5, customView.frame.size.width-40, 80)];
messageLabel.text = @"The Key is Wrong : https://t.me/Yahya_ios ";
messageLabel.numberOfLines = 0;
messageLabel.textColor =[UIColor colorWithRed:255/255.f green:255/255.f blue:255/255.f alpha:1.0];
messageLabel.textAlignment = NSTextAlignmentLeft;

[customView addSubview:messageLabel];

customView.center = CGPointMake(viewController.view.center.x, customView.frame.size.height/2);
[viewController.view addSubview:customView];

dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 5 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{

[userDefaults setObject:nil forKey:@"activationKey"];

            @throw NSInternalInconsistencyException;
});

});


}



            






      [userDefaults setObject:key forKey:@"activationKey"];


}




 }];


}





    

@end


