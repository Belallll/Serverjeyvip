@interface Activation : NSObject

@property (nonatomic, retain) NSURL *activationURL;
@property (nonatomic, retain) NSMutableURLRequest *activationRequest;
//yaha
- (id)init;
- (void)checkActivation:(NSString*)key viewController:(UIViewController*)viewController;
- (void)initRequest;
//mizawi
@end